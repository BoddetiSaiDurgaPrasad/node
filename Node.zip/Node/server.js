const express=require("express");

const app=express();
app.get("/get_data",function(){
    res.send(<h1>Success</h1>)
})

app.post("/send_data",function(req,res)
{
    console.log(req.body);
})

app.get('/', function(req, res){
    res.send('Battu the boss');
})

app.listen(4050,function(){
    console.log("Server running at port number 4050");
});